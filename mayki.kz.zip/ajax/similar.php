 <div class="product-card">
                <a href="/product/774762/caps/color/3" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="caps" data-sex="caps" data-vicolor="3" data-price="1990" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Бейсболка Fuck  2023" src="/catalog_img/774762/caps/1_3_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Бейсболка Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price"><span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">1990</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/face_mask/color/1" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="face_mask" data-sex="face_mask" data-vicolor="1" data-price="1490" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Маска Fuck  2023" src="/catalog_img/774762/face_mask/1_1_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Маска Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price">1990<span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">1490</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/hat/color/2" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="hat" data-sex="hat" data-vicolor="2" data-price="2490" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Шапка Fuck  2023" src="/catalog_img/774762/hat/1_2_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Шапка Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price"><span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">2490</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/hoodie/color/4" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="hoodie" data-sex="hoodie" data-vicolor="4" data-price="6490" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Толстовка худи Fuck  2023" src="/catalog_img/774762/hoodie/1_4_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Толстовка худи Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price">8500<span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">6490</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/man_polo/color/1" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="man_polo" data-sex="wear_man" data-vicolor="1" data-price="3490" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Мужская футболка поло Fuck  2023" src="/catalog_img/774762/man_polo/1_1_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Мужская футболка поло Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price"><span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">3490</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/man_tshirt/color/2" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="man_tshirt" data-sex="wear_man" data-vicolor="2" data-price="2990" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Мужская майка Fuck  2023" src="/catalog_img/774762/man_tshirt/1_2_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Мужская майка Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price"><span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">2990</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/manlong/color/2" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="manlong" data-sex="wear_man" data-vicolor="2" data-price="3490" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Мужская футболка длинный рукав Fuck  2023" src="/catalog_img/774762/manlong/1_2_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Мужская футболка длинный рукав Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price"><span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">3490</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/manshort/color/1" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="manshort" data-sex="wear_man" data-vicolor="1" data-price="2990" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Мужская футболка Fuck  2023" src="/catalog_img/774762/manshort/1_1_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Мужская футболка Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price">4500<span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">2990</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div> <div class="product-card">
                <a href="/product/774762/sweatshirts/color/1" class="js-item-ajax product-wrapper">
                    <span data-id="774762" data-type="sweatshirts" data-sex="sweatshirts" data-vicolor="1" data-price="5990" class="like"></span>
		                  <span class="product-image">						 
                        <img alt="Толстовка без капюшона Fuck  2023" src="/catalog_img/774762/sweatshirts/1_1_zoom_sm.png">
                    </span>
                    <span class="text-block">
                        <span class="product-text">Толстовка без капюшона Fuck  2023</span>
                        <span class="product-price">
                            <!--<span class="old-price">7500<span class="product-tenge"> &#8376;</span></span>-->
                            <span class="current-price">5990</span>
                            <span class="product-tenge"> &#8376;</span>
                        </span>
                    </span>
                    <span class="buy-now-wrapper">
                        <span class="buy-now">Купить в один клик</span>
                    </span>
                </a>
            </div>